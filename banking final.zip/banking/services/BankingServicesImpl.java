package com.cg.banking.services;

public class BankingServicesImpl implements BankingServices {

}
