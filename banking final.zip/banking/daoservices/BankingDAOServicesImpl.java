package com.cg.banking.daoservices;

import java.util.Arrays;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private static Customer[]customerList=new Customer[10];
	private static int CUSTOMER_ID_COUNTER=100;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static int ACCOUNT_ID_COUNTER=1;
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerID(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		if(CUSTOMER_IDX_COUNTER>0.7*customerList.length){
			Customer[] newcustomerList;
			newcustomerList=Arrays.copyOf(customerList, customerList.length+10);
			customerList=newcustomerList;
		}
		return customer.getCustomerID();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++){
			//int ACCOUNT_ID_COUNTER=customerList[i].getACCOUNT_ID_COUNTER();
			int ACCOUNT_IDX_COUNTER=customerList[i].getACCOUNT_IDX_COUNTER();
			if(customerList[i]!=null&&customerList[i].getCustomerID()==customerId){
				account.setAccountNo(ACCOUNT_ID_COUNTER++);
				customerList[i].getAccount()[ACCOUNT_IDX_COUNTER++]=account;
			}
			if(customerList[i].getACCOUNT_IDX_COUNTER()>0.7*customerList[i].getAccount().length){
				Account[] newAccountList;
				newAccountList=Arrays.copyOf(customerList[i].getAccount(), customerList[i].getAccount().length+10);
				customerList[i].setAccount(newAccountList);
			}
		}
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			for(int j=0;j<customerList[i].getAccount().length;j++)
				if(customerList[i]!=null&&customerList[i].getAccount()[j]!=null&&
				customerList[i].getCustomerID()==customerId&&
				customerList[i].getAccount()[j].getAccountNo()==account.getAccountNo()){
					customerList[i].getAccount()[j] =account;
					return true;
				}
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		Random ref = new Random();
		int randomNumber=0;
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerID()==customerId)
				for(int j=0;j<customerList[i].getAccount().length;j++)
					if(customerList[i].getAccount()[j]!=null&&
					customerList[i].getAccount()[j].getAccountNo()==account.getAccountNo())
						randomNumber=1000+ ref.nextInt(9999);
		return randomNumber;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i].getCustomerID()==customerId&&customerList[i]!=null)
				for(int j=0;j<customerList[i].getAccount().length;j++){
					if(customerList[i].getAccount()[j].getTRANSACTION_IDX_COUNTER()>0.7*customerList[i].getAccount().length){
						Transaction[] newTransactionList;
						newTransactionList=Arrays.copyOf(customerList[i].getAccount()[j].getTransaction(), customerList[i].getAccount()[j].getTransaction().length+10);
						customerList[i].getAccount()[j].setTransaction(newTransactionList);
					}
					int transactionIdCounter=customerList[i].getAccount()[j].getTRANSACTION_ID_COUNTER();
					int transactionIdxCounter=customerList[i].getAccount()[j].getTRANSACTION_IDX_COUNTER();
					if(customerList[i].getAccount()[j]!=null&&customerList[i].getAccount()[j].getAccountNo()==accountNo){
						transaction.setTransactionID(transactionIdCounter++);
						customerList[i].getAccount()[j].getTransaction()[transactionIdxCounter++]=transaction;
						return true;
					}
				}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerID()==customerId){
				customerList[i]=null;
				for(int j=i;j<customerList.length-1;j++){
					customerList[j]=customerList[j+1];
					customerList[j+1]=null;
				}
				CUSTOMER_IDX_COUNTER--;
				System.out.println(CUSTOMER_IDX_COUNTER--);
				return true;
			}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++){
			if(customerList[i]!=null&&customerList[i].getCustomerID()==customerId)
				for(int j=0;j<customerList[i].getAccount().length;j++)
					if(customerList[i].getAccount()[j].getAccountNo()==accountNo&&customerList[i].getAccount()[j]!=null){
						customerList[i].getAccount()[j]=null;
						for(int k=i;k<customerList.length-1;k++){
							customerList[k]=customerList[k+1];
							customerList[k+1]=null;
						}
						int ACCOUNT_IDX_COUNTER=customerList[i].getACCOUNT_IDX_COUNTER();
						ACCOUNT_IDX_COUNTER--;
						return true;
					}
		}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerID()==customerId)
				
			
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {

		return null;
	}

	@Override
	public Customer[] getCustomers() {

		return null;
	}

	@Override
	public Account[] getAccounts(int customerId) {

		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {

		return null;
	}

}
